# Pipeline ETL - Monitoramento de Arboviroses e Zoonoses (GEVACZ - Recife)

Este projeto implementa um pipeline completo de **ETL (Extract, Transform, Load)** para extração, limpeza, padronização geoespacial e carga dos dados de monitoramento entomológico de Recife (**GEVACZ**), abrangendo **Estações Disseminadoras de Larvicida (EDLs)** e **Ovitrampas (OVTs)** nos anos de **2024, 2025 e 2026**.

Os dados brutos (distribuídos em arquivos Shapefile, CSV e múltiplas planilhas Excel com layouts distintos) são transformados para atender ao modelo relacional **`Modelo_conceitual_V5`** e carregados em quatro destinos:
1. **SQLite (`gevacz.db`)**: Banco de dados relacional local.
2. **Neon (PostgreSQL)**: Banco de dados relacional em nuvem.
3. **Arquivos JSON (`JSON/`)**: Preservação local de cada tabela estruturada.
4. **MongoDB Atlas**: Banco de dados orientado a documentos em nuvem.

---

## Sumário
- [Estrutura do Projeto](#-estrutura-do-projeto)
- [Arquitetura do Modelo de Dados](#-arquitetura-do-modelo-de-dados)
- [Pré-requisitos](#-pré-requisitos)
- [Passo a Passo de Instalação e Configuração](#-passo-a-passo-de-instalação-e-configuração)
- [Como Executar o Projeto](#-como-executar-o-projeto)
- [Descrição dos Módulos (`src/`)](#-descrição-dos-módulos-src)
- [Solução de Problemas Comuns (Troubleshooting)](#-solução-de-problemas-comuns-troubleshooting)

---

## Estrutura do Projeto

```text
├── Dados_gevacz/                              # Pasta com os dados brutos (extraída de Dados_gevacz.zip)
│   ├── OVITRAMPAS 2024/                       # Planilhas de monitoramento por Distrito Sanitário (2024)
│   ├── OVITRAMPAS 2025/                       # Planilhas de monitoramento por Distrito Sanitário (2025)
│   ├── OVITRAMPAS 2026/                       # Planilha geral de monitoramento (2026)
│   ├── SHAPEFILE EDLs/                        # Shapefiles e planilhas das EDLs por Distrito
│   └── SHAPEFILE OVTs ATUALIZADAS/            # Contém "Georreferenciamento OVT 2026 LIMPO.xlsx"
├── JSON/                                      # (Gerado automaticamente) Tabelas exportadas em formato .json
├── src/                                       # Código-fonte modular do pipeline
│   ├── __init__.py
│   ├── extract.py                             # Leitura de CSV, Shapefiles e planilhas Excel
│   ├── transform.py                           # Limpeza, padronização, cruzamento e modelagem relacional
│   ├── load.py                                # Carga no SQLite, Neon (PostgreSQL), JSON e MongoDB
│   └── queries.py                             # Consultas SQL consolidadas para análise no SQLite e Neon
├── Dados_gevacz.zip                           # Arquivo compactado com a base bruta
├── Modelo_conceitual_V5.pdf                   # Diagrama do modelo relacional do banco de dados
├── dados_EDLs.csv                             # Base consolidada inicial das EDLs
├── gevacz.db                                  # (Gerado automaticamente) Banco de dados SQLite local
├── main.py                                    # Script principal que orquestra todo o pipeline ETL
├── .env                                       # (Criado pelo usuário) Variáveis de ambiente e credenciais
├── requirements.txt                           # Lista de bibliotecas Python necessárias
└── README.md                                  # Documentação do projeto
```

---

## Arquitetura do Modelo de Dados

O pipeline estrutura os dados seguindo rigorosamente o esquema relacional definido no arquivo **`Modelo_conceitual_V5.pdf`**:

| Tabela | Chave Primária (PK) | Chaves Estrangeiras (FK) | Descrição e Regras de Negócio |
| :--- | :--- | :--- | :--- |
| **`local`** | `id_local` | — | Cadastro único de localidades contendo `distrito`, `bairro` e `bairro_area`. Garante unicidade na combinação `(distrito, bairro, bairro_area)`. |
| **`agente`** | `id_agente` | — | Cadastro unificado de agentes de saúde (`nome`, `matricula`). Extraído prioritariamente das ovitrampas e cruzado com EDLs e ciclos. Nomes repetidos sem matrícula são consolidados como uma única pessoa. |
| **`ovitrampas`** | `id_ovitrampa` | `id_local` | Cadastro georreferenciado das ovitrampas (`nome` / código OVT, `endereco`, `latitude`, `longitude`) extraído da planilha `"Georreferenciamento OVT 2026 LIMPO"`. |
| **`edl`** | `id_edl` | `id_local` | Cadastro das Estações Disseminadoras de Larvicida (`nome` / apelido, `endereco`, `referencia`, `latitude`, `longitude`) estruturado a partir de `dados_EDLs.csv` com conversão automática de coordenadas UTM para Graus Decimais (`EPSG:4326`). |
| **`ciclos_2024`** | `id_ciclo` | `id_ovitrampa`, `id_agente` | Monitoramento dos ciclos $1$ a $24$ do ano de 2024 (`ciclo`, `contagem`, `obs`, `data_visita`, `data_contagem`). |
| **`ciclos_2025`** | `id_ciclo` | `id_ovitrampa`, `id_agente` | Monitoramento dos ciclos $1$ a $24$ do ano de 2025. |
| **`ciclos_2026`** | `id_ciclo` | `id_ovitrampa`, `id_agente` | Monitoramento dos ciclos $1$ a $24$ do ano de 2026. |

---

## Pré-requisitos

Antes de começar, certifique-se de ter instalado em seu computador:
* **Python 3.10 ou superior** ([Baixar Python](https://www.python.org/downloads/))
* **Git** (opcional, para clonar o repositório)
* Acesso de conexão com internet (para envio ao **Neon PostgreSQL** e **MongoDB Atlas**).

---

## Passo a Passo de Instalação e Configuração

Siga as instruções abaixo caso esteja configurando o projeto pela primeira vez:

### 1. Abrir o terminal na pasta do projeto
Abra o **Prompt de Comando (CMD)**, **PowerShell** ou terminal do **VS Code** na pasta raiz onde está o arquivo `main.py`.

### 2. Criar o Ambiente Virtual (`venv`)
Execute o comando abaixo para criar um ambiente Python isolado chamado `.venv`:

```bash
python -m venv .venv
```

### 3. Ativar o Ambiente Virtual
* **No Windows (PowerShell):**
  ```powershell
  .\.venv\Scripts\Activate.ps1
  ```
  *(Caso apareça um aviso de permissão de execução de scripts no PowerShell, rode antes: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`)*

* **No Windows (CMD):**
  ```cmd
  .\.venv\Scripts\activate.bat
  ```

* **No Linux ou macOS:**
  ```bash
  source .venv/bin/activate
  ```

Você saberá que o ambiente está ativo quando o prefixo `(.venv)` aparecer no início da linha do seu terminal.

### 4. Instalar as Bibliotecas (`requirements.txt`)
Com o ambiente virtual ativo, instale todas as dependências necessárias com um único comando:

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Configurar o Arquivo `.env` (Credenciais de Banco de Dados)
Crie um arquivo chamado **`.env`** na pasta raiz do projeto (na mesma pasta do `main.py`) e adicione as strings de conexão do **Neon (PostgreSQL)** e do **MongoDB Atlas**:

```env
NEON_URL="postgresql://usuario:senha@ep-exemplo-pooler.us-east-2.aws.neon.tech/neondb?sslmode=require"
MONGO_URL="mongodb+srv://usuario:senha@cluster0.exemplo.mongodb.net/?retryWrites=true&w=majority"
```

> **Importante:** Não deixe os sinais `<` ou `>` ao redor da senha (ex: use `minhasenha` e não `<minhasenha>`). Caso sua senha possua caracteres especiais como `@` ou `#`, o código fará a codificação automaticamente.

---

## Como Executar o Projeto

Certifique-se de que o arquivo `Dados_gevacz.zip` (ou a pasta descompactada `Dados_gevacz/`) e o arquivo `dados_EDLs.csv` estejam na mesma pasta do `main.py`. Em seguida, execute:

```bash
python main.py
```

### O que acontece durante a execução?
1. **Verificação e Extração**: Se a pasta `Dados_gevacz/` ainda não estiver descompactada, o script extrai automaticamente o arquivo `Dados_gevacz.zip`.
2. **Carga Local no SQLite (`gevacz.db`)**: Se o arquivo `gevacz.db` ainda não existir, o código lê as planilhas e CSVs, limpa e cruza os dados e cria todas as tabelas relacionais localmente.
3. **Migração SQLite $\rightarrow$ Neon (PostgreSQL)**: Cria as tabelas no Neon respeitando as chaves estrangeiras e transfere todos os registros em lotes.
4. **Exportação SQLite $\rightarrow$ `JSON/`**: Cria a pasta `JSON/` e salva um arquivo `.json` para cada tabela (`local.json`, `agente.json`, `ovitrampas.json`, `edl.json`, `ciclos_2024.json`, `ciclos_2025.json`, `ciclos_2026.json`).
5. **Carga `JSON/` $\rightarrow$ MongoDB**: Lê os arquivos da pasta `JSON/` e insere os documentos em lotes nas respectivas coleções do banco `gevacz` no MongoDB Atlas.
6. **Fechamento Seguro**: Encerra todas as conexões e pools de banco de dados (`SQLite`, `Neon` e `MongoDB`).

---

## Descrição dos Módulos (`src/`)

* **`src/extract.py` (`Extract`)**:
  Gerencia os caminhos de diretórios e realiza a leitura bruta dos arquivos `dados_EDLs.csv`, dos shapefiles de EDLs, das abas da planilha `"Georreferenciamento OVT 2026 LIMPO.xlsx"` e de todas as planilhas de ciclos de monitoramento das pastas `OVITRAMPAS 2024`, `OVITRAMPAS 2025` e `OVITRAMPAS 2026`.
* **`src/transform.py` (`Transform`)**:
  Concentra todas as regras de negócio:
  * Normalização de strings (remoção de acentos, espaços extras e padronização em caixa alta).
  * Limpeza de coordenadas geográficas corrompidas e conversão do sistema métrico UTM (`EPSG:31985`) para latitude/longitude em graus decimais (`EPSG:4326`).
  * Separação inteligente de nomes e matrículas de agentes e deduplicação de homônimos sem matrícula.
  * Leitura adaptativa para planilhas de monitoramento em formato horizontal de cabeçalho duplo (2024/2025) e em formato tabular vertical (2026), convertendo textos na coluna de ovos (como `"SECA"`, `"FECHADA"`, `"PERDIDA"`) em observações (`obs`).
* **`src/load.py` (`Load`)**:
  Responsável pela criação das tabelas (DDL), inserção em lotes (`chunksize` / `batch_size`) no SQLite, Neon e MongoDB, serialização de valores nulos para JSON padrão e encerramento explícito de conexões (`fechar_conexoes()`).
* **`src/queries.py` (`query`)**:
  Disponibiliza consultas SQL consolidadas (`UNION ALL` entre `ciclos_2024`, `ciclos_2025` e `ciclos_2026` com `JOIN` em `ovitrampas`, `local` e `agente`) prontas para consumo em dashboards ou ferramentas de BI.

---

## Solução de Problemas Comuns (Troubleshooting)

* **Erro `bad auth : Authentication failed (code 8000)` no MongoDB:**
  Verifique no arquivo `.env` se o usuário e a senha da variável `MONGO_URL` estão corretos. No painel do MongoDB Atlas, acesse *Database Access* e confirme se o usuário do banco tem permissão *Read and write to any database* e em *Network Access* se o seu endereço IP está liberado.
* **Erro ao abrir arquivos `.xls` antigos (2024/2025):**
  O Pandas utiliza a biblioteca `xlrd` para arquivos `.xls` (Excel 97-2003) e `openpyxl` para `.xlsx`. Ambas já estão incluídas no `requirements.txt`.
* **Recriar o banco SQLite do zero:**
  Caso deseje rodar novamente toda a extração e transformação a partir das planilhas brutas, basta apagar o arquivo `gevacz.db` da pasta raiz antes de executar `python main.py`.