from pathlib import Path
import pandas as pd
import geopandas as gpd

class Extract:
    def __init__(self, base_dir: str = "."):
        self.base_dir = Path(base_dir).resolve()
        self.dados_dir = self.base_dir / "Dados_gevacz"
        self.pasta_edls = self.dados_dir / "SHAPEFILE EDLs"
        self.arquivo_ovt_geo = (
            self.dados_dir
            / "SHAPEFILE OVTs ATUALIZADAS"
            / "Georreferenciamento OVT 2026 LIMPO.xlsx"
        )
        self.csv_edls = self.base_dir / "dados_EDLs.csv"

    def extract_edls_csv(self) -> pd.DataFrame:
        """Lê o arquivo dados_EDLs.csv na raiz do projeto ou extrai dos shapefiles caso necessário."""
        if self.csv_edls.exists() and self.csv_edls.stat().st_size > 0:
            return pd.read_csv(self.csv_edls)
        return self.extract_edls_from_shapefiles()

    def extract_edls_from_shapefiles(self) -> pd.DataFrame:
        """Extrai os dados dos shapefiles de EDLs convertendo coordenadas para EPSG:4326."""
        gdfs = []
        for shp in sorted(self.pasta_edls.rglob("*.shp")):
            try:
                g = gpd.read_file(shp)
            except Exception as e:
                print(f"Erro ao ler {shp}: {e}")
                continue

            g2 = pd.DataFrame()
            g2["distrito_origem"] = shp.parent.name
            g2["Referencia"] = g["PONTO_ESTR"] if "PONTO_ESTR" in g.columns else g.get("Tipo")
            g2["Bairro"] = g["BAIRRO"] if "BAIRRO" in g.columns else g.get("Bairro")
            g2["Area"] = g["AREA_SESAU"] if "AREA_SESAU" in g.columns else g.get("Area")
            g2["Endereço"] = g.get("Endereço", None)
            g2["Nome_Fantasia"] = g.get("Nome_Fanta", None)
            g2["Area"] = g2["Area"].fillna(g2["Bairro"])
            g2["PE_ou_PA"] = g.get("PE_ou_PA", None)

            if g.crs is not None:
                g_4326 = g.to_crs(epsg=4326)
            else:
                g_4326 = g.set_crs(epsg=31985, allow_override=True).to_crs(epsg=4326)

            pontos = g_4326.geometry.representative_point()
            g2["longitude"] = pontos.x
            g2["latitude"] = pontos.y
            gdfs.append(g2)

        return pd.concat(gdfs, ignore_index=True) if gdfs else pd.DataFrame()

    def extract_agentes_edls(self) -> pd.DataFrame:
        """Extrai informações complementares de agentes/responsáveis das planilhas de EDLs."""
        registros = []
        arq_total_edl = self.dados_dir / "TOTAL DE EDL POR DS.xlsx"
        if arq_total_edl.exists():
            xls = pd.ExcelFile(arq_total_edl)
            for sheet in xls.sheet_names:
                if "TOTAL DE PE" in sheet.upper():
                    continue
                df = pd.read_excel(arq_total_edl, sheet_name=sheet)
                for _, row in df.iterrows():
                    vals = [str(v).strip() for v in row.values if pd.notna(v)]
                    if len(vals) >= 3 and vals[0].isdigit():
                        resp = str(row.iloc[2]).strip() if pd.notna(row.iloc[2]) else None
                        if resp and resp.upper() not in ("RESP. PELO PE", "GEVACZ", "NAN"):
                            registros.append({"agente_bruto": resp, "origem": f"EDL_{sheet}"})
        return pd.DataFrame(registros)

    def extract_ovitrampas_geo(self) -> pd.DataFrame:
        """Extrai todas as abas da planilha 'Georreferenciamento OVT 2026 LIMPO.xlsx' com header=2."""
        xls = pd.ExcelFile(self.arquivo_ovt_geo)
        dfs = []
        for sheet in xls.sheet_names:
            df = pd.read_excel(self.arquivo_ovt_geo, sheet_name=sheet, header=2)
            distrito = sheet.split("-")[0].strip()
            df["DISTRITO"] = distrito
            dfs.append(df)
        return pd.concat(dfs, ignore_index=True)

    def extract_monitoramento_ovitrampas(self) -> dict[int, list[tuple[str, str, pd.DataFrame]]]:
        """
        Extrai as planilhas de monitoramento das pastas OVITRAMPAS 2024, 2025 e 2026,
        ignorando arquivos consolidados de médias por bairro.
        """
        dados_anos = {2024: [], 2025: [], 2026: []}
        pastas = {
            2024: self.dados_dir / "OVITRAMPAS 2024",
            2025: self.dados_dir / "OVITRAMPAS 2025",
            2026: self.dados_dir / "OVITRAMPAS 2026",
        }

        for ano, pasta in pastas.items():
            if not pasta.exists():
                continue
            for arq in sorted(pasta.iterdir()):
                if (
                    arq.suffix.lower() not in (".xls", ".xlsx")
                    or arq.name.startswith("~$")
                    or "CONSOLIDADOS" in arq.name.upper()
                ):
                    continue
                try:
                    xls = pd.ExcelFile(arq)
                    for sheet in xls.sheet_names:
                        df = pd.read_excel(arq, sheet_name=sheet, header=None)
                        if not df.empty:
                            dados_anos[ano].append((arq.name, sheet, df))
                except Exception as e:
                    print(f"Aviso: falha ao ler {arq.name} ({ano}): {e}")

        return dados_anos