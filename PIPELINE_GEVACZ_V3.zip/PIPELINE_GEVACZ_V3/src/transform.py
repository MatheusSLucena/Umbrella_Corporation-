import re
import unicodedata
from pathlib import Path
import pandas as pd
import numpy as np
from pyproj import Transformer

class Transform:
    def __init__(self, csv_edls_path: str = "dados_EDLs.csv"):
        self.csv_edls_path = Path(csv_edls_path)
        self.utm_to_latlon = Transformer.from_crs("EPSG:31985", "EPSG:4326", always_xy=True)

    # -------------------------------------------------------------------------
    # Utilitários de Padronização e Limpeza
    # -------------------------------------------------------------------------
    @staticmethod
    def normalizar_texto(texto) -> str:
        if pd.isna(texto) or texto is None:
            return ""
        s = str(texto).strip().upper()
        s = unicodedata.normalize("NFKD", s)
        s = "".join(c for c in s if not unicodedata.combining(c))
        s = re.sub(r"\s+", " ", s)
        return s

    @staticmethod
    def limpar_coord(val) -> float | None:
        if pd.isna(val) or val is None:
            return None
        s = str(val).strip().replace(",", ".")
        s = re.sub(r"[^\d\.\-]", "", s)
        if not s or s in ("-", "."):
            return None
        try:
            num = float(s)
            while abs(num) > 180:
                num /= 10.0
            return round(num, 7)
        except ValueError:
            return None

    @staticmethod
    def separar_bairro_e_area(bairro_area_raw: str) -> tuple[str, str]:
        area = Transform.normalizar_texto(bairro_area_raw)
        if not area:
            return ("NAO INFORMADO", "NAO INFORMADO")
        bairro_base = re.sub(r"\s+(\bI{1,3}\b|\bIV\b|\bV\b|\d+|0\d|\(.*\))$", "", area).strip()
        if not bairro_base:
            bairro_base = area
        return (bairro_base, area)

    @staticmethod
    def parse_agente_matricula(valor_bruto) -> tuple[str, str | None]:
        if pd.isna(valor_bruto) or valor_bruto is None:
            return ("NAO IDENTIFICADO", None)
        bruto = str(valor_bruto).strip()
        if not bruto or bruto.upper() in ("NAN", "NONE", "-", "S/I"):
            return ("NAO IDENTIFICADO", None)

        if "/" in bruto:
            partes = bruto.split("/", 1)
            nome = Transform.normalizar_texto(partes[0])
            mat_raw = partes[1].strip()
        else:
            m = re.search(r"^(.*?)[\s\-]+(\d[\d\.\-]{3,})$", bruto)
            if m:
                nome = Transform.normalizar_texto(m.group(1))
                mat_raw = m.group(2)
            else:
                nome = Transform.normalizar_texto(bruto)
                mat_raw = None

        # Evita tratar números puros curtos (ex: '38', '66') como nomes de agentes válidos
        if nome and re.match(r"^\d+$", nome):
            return ("NAO IDENTIFICADO", None)

        if mat_raw:
            mat_limpa = re.sub(r"[^\d]", "", mat_raw)
            matricula = mat_limpa if len(mat_limpa) >= 3 else None
        else:
            matricula = None

        if not nome:
            nome = "NAO IDENTIFICADO"
        return (nome, matricula)

    # -------------------------------------------------------------------------
    # 1. Dados iniciais das EDLs (CSV dados_EDLs)
    # -------------------------------------------------------------------------
    def carregar_dados_edls(self) -> pd.DataFrame:
        df = pd.read_csv(self.csv_edls_path)
        if "Unnamed: 0" in df.columns:
            df = df.drop(columns=["Unnamed: 0"])
        return df

    # -------------------------------------------------------------------------
    # 2. Processamento de Ovitrampas ("Georreferenciamento OVT 2026 LIMPO")
    # -------------------------------------------------------------------------
    def preparar_ovitrampas_brutas(self, df_ovt_raw: pd.DataFrame) -> pd.DataFrame:
        df = df_ovt_raw.copy()
        col_map = {}
        for c in df.columns:
            cu = str(c).strip().upper()
            if cu == "BAIRRO":
                col_map[c] = "bairro_area_raw"
            elif "ID OVT" in cu or cu == "OVT":
                col_map[c] = "nome"
            elif "LAT" in cu:
                col_map[c] = "latitude"
            elif "LONG" in cu:
                col_map[c] = "longitude"
            elif "ENDERE" in cu:
                col_map[c] = "endereco"
            elif "AGENTE" in cu or "MATR" in cu:
                col_map[c] = "agente_matricula"
            elif "DISTRITO" in cu:
                col_map[c] = "distrito"

        df = df.rename(columns=col_map)
        df = df.dropna(subset=["nome"]).copy()
        df = df[~df["nome"].astype(str).str.upper().str.contains("ID OVT", na=False)].copy()

        df["nome"] = df["nome"].astype(str).str.strip().str.upper()
        df["nome_chave"] = df["nome"].str.replace(r"\s+", "", regex=True)
        df["distrito"] = df["distrito"].apply(self.normalizar_texto)
        df["endereco"] = df["endereco"].fillna("NAO INFORMADO").astype(str).str.strip()
        df["latitude"] = df["latitude"].apply(self.limpar_coord)
        df["longitude"] = df["longitude"].apply(self.limpar_coord)

        bairros_parsed = df["bairro_area_raw"].apply(self.separar_bairro_e_area)
        df["bairro"] = [b[0] for b in bairros_parsed]
        df["bairro_area"] = [b[1] for b in bairros_parsed]

        agentes_parsed = df["agente_matricula"].apply(self.parse_agente_matricula)
        df["agente_nome"] = [a[0] for a in agentes_parsed]
        df["agente_matricula_limpa"] = [a[1] for a in agentes_parsed]

        df = df.drop_duplicates(subset=["nome_chave"], keep="first").reset_index(drop=True)
        return df

    # -------------------------------------------------------------------------
    # 3. Construção da Tabela Única de Locais (`local`)
    # -------------------------------------------------------------------------
    def construir_tabela_local(self, df_ovt: pd.DataFrame, df_edl_raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
        locais_ovt = df_ovt[["distrito", "bairro", "bairro_area"]].drop_duplicates().copy()

        mapa_bairro_distrito = (
            locais_ovt.drop_duplicates(subset=["bairro"])
            .set_index("bairro")["distrito"]
            .to_dict()
        )
        mapa_area_distrito = (
            locais_ovt.drop_duplicates(subset=["bairro_area"])
            .set_index("bairro_area")["distrito"]
            .to_dict()
        )

        df_edl_loc = pd.DataFrame()
        df_edl_loc["bairro"] = df_edl_raw["Bairro"].apply(self.normalizar_texto)
        df_edl_loc["bairro_area"] = df_edl_raw["Area"].fillna(df_edl_raw["Bairro"]).apply(self.normalizar_texto)

        regras_ds = {
            "DS I": ["RECIFE", "BOA VISTA", "COELHOS", "SANTO AMARO", "SAO JOSE", "SANTO ANTONIO", "JOANA BEZERRA", "CABANGA", "ILHA DO LEITE", "SOLEDADE", "PAISSANDU"],
            "DS II": ["AGUA FRIA", "ARRUDA", "BEBERIBE", "BOMBA DO HEMETERIO", "CAJUEIRO", "CAMPINA DO BARRETO", "CAMPO GRANDE", "DOIS UNIDOS", "ENCRUZILHADA", "FUNDAO", "HIPODROMO", "LINHA DO TIRO", "PEIXINHOS", "PONTO DE PARADA", "PORTO DA MADEIRA", "ROSARINHO", "TORREAO", "ALTO SANTA TEREZINHA"],
            "DS III": ["AFLITOS", "ALTO DO MANDU", "APIPUCOS", "CASA AMARELA", "CASA FORTE", "DERBY", "DOIS IRMAOS", "ESPINHEIRO", "GRACAS", "JAQUEIRA", "MONTEIRO", "PARNAMIRIM", "POCO", "POCO DA PANELA", "SANTANA", "SITIO DOS PINTOS", "TAMARINEIRA"],
            "DS IV": ["CAXANGA", "CIDADE UNIVERSITARIA", "CORDEIRO", "ENGENHO DO MEIO", "ILHA DO RETIRO", "IPUTINGA", "MADALENA", "PRADO", "TORRE", "TORROES", "VARZEA", "ZUMBI"],
            "DS V": ["AFOGADOS", "AREIAS", "BARRO", "BONGI", "CACOTE", "COQUEIRAL", "CURADO", "ESTANCIA", "JARDIM SAO PAULO", "JIQUIA", "MANGUEIRA", "MUSTARDINHA", "SAN MARTIN", "SANCHO", "TEJIPIO", "TOTO"],
            "DS VI": ["BOA VIAGEM", "BRASILIA TEIMOSA", "IMBIRIBEIRA", "IPSEP", "PINA"],
            "DS VII": ["ALTO JOSE BONIFACIO", "ALTO JOSE DO PINHO", "BREJO DA GUABIRABA", "BREJO DE BEBERIBE", "CORREGO DO JENIPAPO", "GUABIRABA", "MACAXEIRA", "MANGABEIRA", "MORRO DA CONCEICAO", "NOVA DESCOBERTA", "PASSARINHO", "PAU FERRO", "VASCO DA GAMA"],
            "DS VIII": ["COHAB", "IBURA", "JORDAO"],
        }

        def inferir_distrito(row):
            b, a = row["bairro"], row["bairro_area"]
            if a in mapa_area_distrito:
                return mapa_area_distrito[a]
            if b in mapa_bairro_distrito:
                return mapa_bairro_distrito[b]
            for ds, lista_b in regras_ds.items():
                if any(b_ref in b or b_ref in a for b_ref in lista_b):
                    return ds
            return "NAO INFORMADO"

        df_edl_loc["distrito"] = df_edl_loc.apply(inferir_distrito, axis=1)

        df_local = (
            pd.concat([locais_ovt, df_edl_loc[["distrito", "bairro", "bairro_area"]]], ignore_index=True)
            .drop_duplicates(subset=["distrito", "bairro", "bairro_area"])
            .sort_values(["distrito", "bairro", "bairro_area"])
            .reset_index(drop=True)
        )
        df_local["id_local"] = df_local.index + 1
        df_local = df_local[["id_local", "distrito", "bairro", "bairro_area"]]

        lookup_local = {
            (r.distrito, r.bairro, r.bairro_area): r.id_local
            for r in df_local.itertuples(index=False)
        }
        return df_local, lookup_local

    # -------------------------------------------------------------------------
    # 4. Estruturação Final de `edl` e `ovitrampas`
    # -------------------------------------------------------------------------
    def estruturar_edls(self, df_edl_raw: pd.DataFrame, df_local: pd.DataFrame, lookup_local: dict) -> pd.DataFrame:
        df = df_edl_raw.copy()
        df["bairro_norm"] = df["Bairro"].apply(self.normalizar_texto)
        df["area_norm"] = df["Area"].fillna(df["Bairro"]).apply(self.normalizar_texto)

        mapa_area_id = df_local.drop_duplicates("bairro_area").set_index("bairro_area")["id_local"].to_dict()
        mapa_bairro_id = df_local.drop_duplicates("bairro").set_index("bairro")["id_local"].to_dict()

        def obter_id_local(row):
            if row["area_norm"] in mapa_area_id:
                return mapa_area_id[row["area_norm"]]
            return mapa_bairro_id.get(row["bairro_norm"], 1)

        lats, lons = [], []
        for _, r in df.iterrows():
            x, y = r.get("longitude"), r.get("latitude")
            if pd.notna(x) and pd.notna(y):
                if abs(float(x)) > 180 or abs(float(y)) > 180:
                    lon, lat = self.utm_to_latlon.transform(float(x), float(y))
                    lats.append(round(lat, 7))
                    lons.append(round(lon, 7))
                else:
                    lats.append(round(float(y), 7))
                    lons.append(round(float(x), 7))
            else:
                lats.append(None)
                lons.append(None)

        df_final = pd.DataFrame()
        df_final["id_edl"] = range(1, len(df) + 1)
        df_final["id_local"] = df.apply(obter_id_local, axis=1)
        df_final["nome"] = (
            df["Nome_Fantasia"]
            .fillna(df["Referencia"])
            .fillna("EDL SEM NOME")
            .astype(str)
            .str.strip()
        )
        df_final["endereco"] = df["Endereço"].fillna("NAO INFORMADO").astype(str).str.strip()
        df_final["referencia"] = df["Referencia"].fillna(df.get("PE_ou_PA", "OUTROS")).astype(str).str.strip()
        df_final["latitude"] = lats
        df_final["longitude"] = lons

        return df_final

    def estruturar_ovitrampas(self, df_ovt_prep: pd.DataFrame, lookup_local: dict) -> pd.DataFrame:
        df_final = pd.DataFrame()
        df_final["id_ovitrampa"] = range(1, len(df_ovt_prep) + 1)
        df_final["id_local"] = [
            lookup_local.get((r.distrito, r.bairro, r.bairro_area), 1)
            for r in df_ovt_prep.itertuples(index=False)
        ]
        df_final["nome"] = df_ovt_prep["nome"].values
        df_final["endereco"] = df_ovt_prep["endereco"].values
        df_final["latitude"] = df_ovt_prep["latitude"].values
        df_final["longitude"] = df_ovt_prep["longitude"].values
        return df_final

    # -------------------------------------------------------------------------
    # 5. Construção e Cruzamento da Tabela de Agentes (`agente`)
    # -------------------------------------------------------------------------
    def extrair_agentes_monitoramento(self, dados_monitoramento: dict) -> list[str]:
        """Coleta os nomes/matrículas de agentes presentes nas planilhas de 2024, 2025 e 2026."""
        agentes = []
        for _, planilhas in dados_monitoramento.items():
            for nome_arq, _, df in planilhas:
                if df.empty or len(df) < 2 or "CONSOLIDADOS" in nome_arq.upper():
                    continue
                for i in range(min(20, len(df))):
                    vals = [str(x).strip().upper() if pd.notna(x) else "" for x in df.iloc[i].values]
                    if any("OVT" in v for v in vals) and any("AGENTE" in v for v in vals):
                        for j, v in enumerate(vals):
                            if "AGENTE" in v:
                                col_ag = df.iloc[i + 1 :, j].dropna().astype(str).unique().tolist()
                                agentes.extend(col_ag)
                        break
        return agentes

    def construir_tabela_agentes(
        self,
        df_ovt_prep: pd.DataFrame,
        df_agentes_edl: pd.DataFrame = None,
        dados_monitoramento: dict = None,
    ) -> tuple[pd.DataFrame, dict]:
        lista_bruta = []

        # 1º: Agentes das Ovitrampas (Georreferenciamento OVT 2026 LIMPO)
        for _, r in df_ovt_prep.iterrows():
            lista_bruta.append((r["agente_nome"], r["agente_matricula_limpa"]))

        # 2º: Agentes das EDLs
        if df_agentes_edl is not None and not df_agentes_edl.empty:
            for val in df_agentes_edl["agente_bruto"].dropna():
                lista_bruta.append(self.parse_agente_matricula(val))

        # 3º: Agentes presentes nas planilhas de ciclos (2024, 2025, 2026)
        if dados_monitoramento is not None:
            for val in self.extrair_agentes_monitoramento(dados_monitoramento):
                lista_bruta.append(self.parse_agente_matricula(val))

        por_matricula = {}
        nome_para_matriculas = {}

        for nome, mat in lista_bruta:
            if not nome:
                nome = "NAO IDENTIFICADO"
            if mat:
                if mat not in por_matricula:
                    por_matricula[mat] = nome
                else:
                    if len(nome) > len(por_matricula[mat]) and nome != "NAO IDENTIFICADO":
                        por_matricula[mat] = nome
                nome_para_matriculas.setdefault(nome, set()).add(mat)

        registros_finais = []
        mapa_lookup_agente = {}

        for mat, nome in sorted(por_matricula.items(), key=lambda x: x[1]):
            id_ag = len(registros_finais) + 1
            registros_finais.append({"id_agente": id_ag, "nome": nome, "matricula": mat})
            mapa_lookup_agente[(nome, mat)] = id_ag
            mapa_lookup_agente[mat] = id_ag
            if len(nome_para_matriculas.get(nome, [])) == 1:
                mapa_lookup_agente[nome] = id_ag

        # Nomes repetidos sem identificação (matrícula) são tratados como uma pessoa só
        nomes_sem_mat = sorted({nome for nome, mat in lista_bruta if not mat})
        for nome in nomes_sem_mat:
            if nome in mapa_lookup_agente:
                continue
            id_ag = len(registros_finais) + 1
            registros_finais.append({"id_agente": id_ag, "nome": nome, "matricula": None})
            mapa_lookup_agente[nome] = id_ag
            mapa_lookup_agente[(nome, None)] = id_ag

        if "NAO IDENTIFICADO" not in mapa_lookup_agente:
            id_ag = len(registros_finais) + 1
            registros_finais.append({"id_agente": id_ag, "nome": "NAO IDENTIFICADO", "matricula": None})
            mapa_lookup_agente["NAO IDENTIFICADO"] = id_ag

        df_agente = pd.DataFrame(registros_finais)
        return df_agente, mapa_lookup_agente

    # -------------------------------------------------------------------------
    # 6. Extração e Transformação dos Dados de Monitoramento (2024, 2025, 2026)
    # -------------------------------------------------------------------------
    def extrair_ciclos_das_planilhas(
        self,
        dados_monitoramento: dict[int, list[tuple[str, str, pd.DataFrame]]],
        df_ovitrampas: pd.DataFrame,
        df_ovt_prep: pd.DataFrame,
        lookup_agente: dict,
    ) -> dict[int, pd.DataFrame]:
        mapa_ovt_id = {}
        mapa_ovt_agente_padrao = {}

        for _, row in df_ovitrampas.iterrows():
            chave = re.sub(r"\s+", "", str(row["nome"]).upper())
            mapa_ovt_id[chave] = int(row["id_ovitrampa"])

        for _, row in df_ovt_prep.iterrows():
            chave = row["nome_chave"]
            id_ovt = mapa_ovt_id.get(chave)
            if id_ovt:
                ag_id = (
                    lookup_agente.get((row["agente_nome"], row["agente_matricula_limpa"]))
                    or lookup_agente.get(row["agente_matricula_limpa"])
                    or lookup_agente.get(row["agente_nome"])
                    or lookup_agente["NAO IDENTIFICADO"]
                )
                mapa_ovt_agente_padrao[id_ovt] = int(ag_id)

        padrao_ovt = re.compile(r"^[A-Z]{2,4}\s*\d{3,5}[A-Z]?$")
        tabelas_ciclos = {}

        for ano, lista_planilhas in dados_monitoramento.items():
            registros_ano = []

            for nome_arq, nome_aba, df in lista_planilhas:
                if df.empty or len(df) < 2 or "CONSOLIDADOS" in nome_arq.upper():
                    continue

                # 1. Localiza a linha de cabeçalho que contém ID. OVT / ID_OVT / ID OVT
                header_idx = None
                col_ovt = None
                for i in range(min(25, len(df))):
                    linha_str = [str(x).strip().upper() if pd.notna(x) else "" for x in df.iloc[i].values]
                    for j, val in enumerate(linha_str):
                        if val in ("ID OVT", "ID. OVT", "ID_OVT", "OVT", "Nº OVT", "COD OVT"):
                            header_idx = i
                            col_ovt = j
                            break
                    if header_idx is not None:
                        break

                # Fallback seguro (evita erro de Series vazia com str.match)
                if col_ovt is None:
                    for j in range(min(10, df.shape[1])):
                        amostra = df.iloc[:, j].dropna().astype(str).str.strip().str.upper()
                        if amostra.empty:
                            continue
                        matches = amostra.str.match(padrao_ovt, na=False)
                        if int(matches.sum()) >= 3:
                            col_ovt = j
                            first_pos = int(np.flatnonzero(matches.values)[0])
                            header_idx = max(0, first_pos - 1)
                            break

                if col_ovt is None:
                    continue

                cabecalho = [
                    str(x).strip().upper() if pd.notna(x) else ""
                    for x in df.iloc[header_idx].values
                ]

                # CASO A: Formato Longo (ex: PLANILHA GERAL OVT 2026.xlsx com colunas CICLOS, ID_OVT, DT_COLETA, DT_LEITURA, N_OVOS, OBS)
                if "CICLOS" in cabecalho or "CICLO" in cabecalho:
                    col_ciclo = cabecalho.index("CICLOS") if "CICLOS" in cabecalho else cabecalho.index("CICLO")
                    col_ag = next((j for j, h in enumerate(cabecalho) if "AGENTE" in h), None)
                    col_dt_vis = next((j for j, h in enumerate(cabecalho) if h in ("DT_COLETA", "DATA_VISITA", "DATA")), None)
                    col_dt_cnt = next((j for j, h in enumerate(cabecalho) if h in ("DT_LEITURA", "DATA_CONTAGEM")), None)
                    col_ovos = next((j for j, h in enumerate(cabecalho) if "OVOS" in h or "CONTAGEM" in h), None)
                    col_obs = next((j for j, h in enumerate(cabecalho) if "OBS" in h), None)

                    for i in range(header_idx + 1, len(df)):
                        val_ovt = df.iloc[i, col_ovt]
                        if pd.isna(val_ovt):
                            continue
                        chave_ovt = re.sub(r"\s+", "", str(val_ovt).strip().upper())
                        id_ovt = mapa_ovt_id.get(chave_ovt)
                        if not id_ovt:
                            continue

                        try:
                            num_ciclo = int(float(df.iloc[i, col_ciclo]))
                        except (ValueError, TypeError):
                            continue
                        if not (1 <= num_ciclo <= 24):
                            continue

                        id_ag = mapa_ovt_agente_padrao.get(id_ovt, lookup_agente["NAO IDENTIFICADO"])
                        if col_ag is not None and pd.notna(df.iloc[i, col_ag]):
                            nome_ag, mat_ag = self.parse_agente_matricula(df.iloc[i, col_ag])
                            id_ag = (
                                lookup_agente.get((nome_ag, mat_ag))
                                or lookup_agente.get(mat_ag)
                                or lookup_agente.get(nome_ag)
                                or id_ag
                            )

                        dt_vis = pd.to_datetime(df.iloc[i, col_dt_vis], errors="coerce") if col_dt_vis is not None else pd.NaT
                        dt_cnt = pd.to_datetime(df.iloc[i, col_dt_cnt], errors="coerce") if col_dt_cnt is not None else pd.NaT
                        obs_val = str(df.iloc[i, col_obs]).strip() if (col_obs is not None and pd.notna(df.iloc[i, col_obs])) else None
                        cel_ovos = df.iloc[i, col_ovos] if col_ovos is not None else None

                        contagem, obs_final = self._interpretar_valor_contagem(cel_ovos, obs_val)
                        if contagem is None and obs_final is None and pd.isna(dt_vis):
                            continue

                        registros_ano.append({
                            "id_ovitrampa": id_ovt,
                            "id_agente": id_ag,
                            "ciclo": num_ciclo,
                            "contagem": contagem,
                            "obs": obs_final,
                            "data_visita": None if pd.isna(dt_vis) else dt_vis.strftime("%Y-%m-%d %H:%M:%S"),
                            "data_contagem": None if pd.isna(dt_cnt) else dt_cnt.strftime("%Y-%m-%d %H:%M:%S"),
                        })

                # CASO B: Formato Largo de Cabeçalho Duplo (Planilha OVT DS-I..VIII de 2024 e 2025)
                elif header_idx > 0:
                    linha_ciclos = [
                        str(x).strip().upper() if pd.notna(x) else ""
                        for x in df.iloc[header_idx - 1].values
                    ]
                    col_ag = next((j for j, h in enumerate(cabecalho) if "AGENTE" in h), None)

                    blocos_ciclo = {}
                    for j, val_c in enumerate(linha_ciclos):
                        m_c = re.search(r"CICLO\s*0?(\d{1,2})", val_c)
                        if m_c:
                            c_num = int(m_c.group(1))
                            if 1 <= c_num <= 24:
                                col_dt = j if j < len(cabecalho) and "DATA" in cabecalho[j] else None
                                col_ov = j + 1 if (j + 1) < len(cabecalho) else None
                                col_ob = j + 2 if (j + 2) < len(cabecalho) and "OBS" in cabecalho[j + 2] else None
                                blocos_ciclo[c_num] = (col_dt, col_ov, col_ob)

                    for i in range(header_idx + 1, len(df)):
                        val_ovt = df.iloc[i, col_ovt]
                        if pd.isna(val_ovt):
                            continue
                        chave_ovt = re.sub(r"\s+", "", str(val_ovt).strip().upper())
                        id_ovt = mapa_ovt_id.get(chave_ovt)
                        if not id_ovt:
                            continue

                        id_ag = mapa_ovt_agente_padrao.get(id_ovt, lookup_agente["NAO IDENTIFICADO"])
                        if col_ag is not None and pd.notna(df.iloc[i, col_ag]):
                            nome_ag, mat_ag = self.parse_agente_matricula(df.iloc[i, col_ag])
                            id_ag = (
                                lookup_agente.get((nome_ag, mat_ag))
                                or lookup_agente.get(mat_ag)
                                or lookup_agente.get(nome_ag)
                                or id_ag
                            )

                        for c_num, (c_dt, c_ov, c_ob) in blocos_ciclo.items():
                            raw_dt = df.iloc[i, c_dt] if (c_dt is not None and c_dt < df.shape[1]) else None
                            raw_ov = df.iloc[i, c_ov] if (c_ov is not None and c_ov < df.shape[1]) else None
                            raw_ob = df.iloc[i, c_ob] if (c_ob is not None and c_ob < df.shape[1]) else None

                            if pd.isna(raw_dt) and pd.isna(raw_ov) and pd.isna(raw_ob):
                                continue

                            dt_vis = pd.to_datetime(raw_dt, errors="coerce") if pd.notna(raw_dt) else pd.NaT
                            obs_val = str(raw_ob).strip() if pd.notna(raw_ob) and str(raw_ob).strip() != "" else None
                            contagem, obs_final = self._interpretar_valor_contagem(raw_ov, obs_val)

                            if contagem is None and obs_final is None and pd.isna(dt_vis):
                                continue

                            registros_ano.append({
                                "id_ovitrampa": id_ovt,
                                "id_agente": id_ag,
                                "ciclo": c_num,
                                "contagem": contagem,
                                "obs": obs_final,
                                "data_visita": None if pd.isna(dt_vis) else dt_vis.strftime("%Y-%m-%d %H:%M:%S"),
                                "data_contagem": None,
                            })

            df_ano = pd.DataFrame(
                registros_ano,
                columns=[
                    "id_ovitrampa",
                    "id_agente",
                    "ciclo",
                    "contagem",
                    "obs",
                    "data_visita",
                    "data_contagem",
                ],
            )
            if not df_ano.empty:
                df_ano = (
                    df_ano.sort_values(by=["contagem", "data_visita"], na_position="last")
                    .drop_duplicates(subset=["id_ovitrampa", "ciclo"], keep="first")
                    .sort_values(["id_ovitrampa", "ciclo"])
                    .reset_index(drop=True)
                )
            df_ano.insert(0, "id_ciclo", range(1, len(df_ano) + 1))
            tabelas_ciclos[ano] = df_ano

        return tabelas_ciclos

    @staticmethod
    def _interpretar_valor_contagem(valor, obs_atual: str | None) -> tuple[int | None, str | None]:
        if pd.isna(valor) or str(valor).strip() == "":
            return (None, obs_atual)
        if isinstance(valor, (int, np.integer)):
            return (int(valor), obs_atual)
        if isinstance(valor, (float, np.floating)):
            return (int(round(valor)), obs_atual)
        s = str(valor).strip()
        try:
            return (int(round(float(s))), obs_atual)
        except ValueError:
            obs_nova = f"{obs_atual}; {s}" if obs_atual else s
            return (None, obs_nova)