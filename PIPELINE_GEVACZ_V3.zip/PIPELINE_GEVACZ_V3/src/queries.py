import sqlite3
import psycopg2  # pip install psycopg2-binary
from dotenv import load_dotenv
import os
import psycopg2
from  sqlalchemy import create_engine


load_dotenv()

""" Explora os dados no Neon e no SQLite """
class query():



    def __init__(self):
        self.neon_url = os.getenv('NEON_URL')
        self.engine_neon = create_engine(self.neon_url,echo=True,pool_size=5,pool_pre_ping=True)
        self.anos = (2024, 2025, 2026)
        self.nome_sqlite = "gevacz.db"


    def query_consolidada(self) -> str:
        """Consulta final. SQL padrão (funciona em SQLite e PostgreSQL)."""
        blocos = "\nUNION ALL\n".join(
            f"SELECT {ano} AS ano, id_ciclo, ciclo, id_ovitrampa, id_agente, "
            f"contagem, data_visita, data_contagem, obs FROM ciclos_{ano}"
            for ano in self.anos
        )
        return f"""
            WITH ciclos_todos AS (
            {blocos}
            )
            SELECT
                c.ano,
                c.ciclo,
                l.distrito,
                l.bairro,
                l.bairro_area,
                a.nome             AS nome_agente,
                a.matricula        AS matricula_agente,
                o.nome             AS nome_ovitrampa,
                c.contagem,
                c.data_visita,
                c.data_contagem
            FROM ciclos_todos c
            JOIN ovitrampas o ON o.id_ovitrampa = c.id_ovitrampa
            JOIN local      l ON l.id_local     = o.id_local
            JOIN agente     a ON a.id_agente    = c.id_agente
            ORDER BY c.ano, c.ciclo, l.distrito, l.bairro, o.nome;
            """




    # ----------------------------------------------------------------- SQLite

    def consultar_ciclos_sqlite(self): 
        conn = sqlite3.connect(self.nome_sqlite)
        try:
            conn.execute("PRAGMA foreign_keys = ON;")
            cur = conn.cursor()
            cur.execute(self.query_consolidada(self.anos))
            colunas = [d[0] for d in cur.description]
            return colunas, cur.fetchall()
        finally:
            conn.close()


    # ------------------------------------------------------------------ Neon

    def consultar_ciclos_neon(self):
        conn = psycopg2.connect(self.engine_neon)
        try:
            with conn.cursor() as cur:
                cur.execute(self.query_consolidada(self.anos))
                colunas = [d[0] for d in cur.description]
                return colunas, cur.fetchall()
        finally:
            conn.close()