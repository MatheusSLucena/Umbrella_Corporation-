import json
import os
import sqlite3
from pathlib import Path
import certifi
import numpy as np
import pandas as pd
from dotenv import load_dotenv
from pymongo import MongoClient
from pymongo.server_api import ServerApi
from sqlalchemy import create_engine, text
import re
from urllib.parse import quote_plus
from pymongo.errors import OperationFailure

load_dotenv()


class Load:
    def __init__(self, db_path: str = "gevacz.db", json_dir: str = "JSON"):
        self.db_path = Path(db_path).resolve()
        self.json_dir = Path(json_dir).resolve()
        self.json_dir.mkdir(parents=True, exist_ok=True)

        self.mongo_uri = self._sanitizar_mongo_uri(os.getenv("MONGO_URL"))
        self.neon_url = os.getenv("NEON_URL")
        self.anos = (2024, 2025, 2026)

        # Ordenação lógica respeitando as chaves estrangeiras (FKs)
        self.tabelas = [
            "local",
            "agente",
            "ovitrampas",
            "edl",
            *[f"ciclos_{ano}" for ano in self.anos],
        ]

        self.client = (
            MongoClient(
                self.mongo_uri,
                server_api=ServerApi("1"),
                tlsCAFile=certifi.where(),
            )
            if self.mongo_uri
            else None
        )
        self.engine_neon = (
            create_engine(
                self.neon_url,
                echo=False,
                pool_size=5,
                pool_pre_ping=True,
            )
            if self.neon_url
            else None
        )
        self.engine_sqlite = create_engine(f"sqlite:///{self.db_path}")


    @staticmethod
    def _sanitizar_mongo_uri(uri: str | None) -> str | None:
        """
        Remove '<' e '>' acidentais da senha e aplica URL-encode (quote_plus)
        no usuário e senha caso contenham caracteres especiais (@, :, /, #, etc.).
        """
        if not uri:
            return None
        uri = uri.strip().strip('"').strip("'")
        m = re.match(r"^(mongodb(?:\+srv)?://)(.+)\@([^@]+)$", uri)
        if not m:
            return uri
        prefixo, credenciais, resto = m.groups()
        if ":" in credenciais:
            usuario, senha = credenciais.split(":", 1)
            # Remove < e > caso tenham ficado do template do Atlas (<password>)
            senha = senha.strip("<>")
            usuario = usuario.strip("<>")
            # Aplica quote_plus apenas se ainda não estiver codificado
            if "%" not in usuario:
                usuario = quote_plus(usuario)
            if "%" not in senha:
                senha = quote_plus(senha)
            return f"{prefixo}{usuario}:{senha}@{resto}"
        return uri

    # ----------------------------------------------------------------- SQLite
    def criar_tabelas_relacionais_sqlite(self):
        """Cria as tabelas relacionais no SQLite seguindo o Modelo_conceitual_V5."""
        query = """
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS local (
            id_local     INTEGER PRIMARY KEY,
            distrito     VARCHAR NOT NULL,
            bairro       VARCHAR NOT NULL,
            bairro_area  VARCHAR,
            UNIQUE (distrito, bairro, bairro_area)
        );

        CREATE TABLE IF NOT EXISTS edl (
            id_edl      INTEGER PRIMARY KEY,
            id_local    INTEGER NOT NULL REFERENCES local(id_local),
            nome        VARCHAR NOT NULL,
            endereco    VARCHAR,
            referencia  VARCHAR,
            latitude    FLOAT,
            longitude   FLOAT
        );

        CREATE TABLE IF NOT EXISTS ovitrampas (
            id_ovitrampa  INTEGER PRIMARY KEY,
            id_local      INTEGER NOT NULL REFERENCES local(id_local),
            nome          VARCHAR NOT NULL,
            endereco      VARCHAR,
            latitude      FLOAT,
            longitude     FLOAT
        );

        CREATE TABLE IF NOT EXISTS agente (
            id_agente  INTEGER PRIMARY KEY,
            nome       VARCHAR NOT NULL,
            matricula  VARCHAR UNIQUE
        );
        """
        for ano in self.anos:
            query += f"""
            CREATE TABLE IF NOT EXISTS ciclos_{ano} (
                id_ciclo        INTEGER PRIMARY KEY,
                id_ovitrampa    INTEGER NOT NULL REFERENCES ovitrampas(id_ovitrampa),
                id_agente       INTEGER NOT NULL REFERENCES agente(id_agente),
                ciclo           INTEGER NOT NULL CHECK (ciclo BETWEEN 1 AND 24),
                contagem        INTEGER,
                obs             VARCHAR,
                data_visita     DATETIME,
                data_contagem   DATETIME,
                UNIQUE (id_ovitrampa, ciclo)
            );
            """

        conn = sqlite3.connect(self.db_path)
        try:
            conn.executescript(query)
            conn.commit()
        finally:
            conn.close()

    def load_sqlite(self, data: pd.DataFrame, nome_tabela: str):
        """Salva um DataFrame no banco SQLite gevacz.db."""
        conn = sqlite3.connect(self.db_path)
        try:
            data.to_sql(nome_tabela, con=conn, if_exists="append", index=False)
            conn.commit()
            print(f"[SQLite] Tabela '{nome_tabela}' carregada ({len(data)} registros).")
        finally:
            conn.close()

    def ler_tabela_sqlite(self, nome_tabela: str) -> pd.DataFrame:
        """Lê todos os dados de uma tabela do SQLite e fecha a conexão."""
        conn = sqlite3.connect(self.db_path)
        try:
            return pd.read_sql_query(f"SELECT * FROM {nome_tabela}", con=conn)
        finally:
            conn.close()

    # ------------------------------------------------------------------ Neon (PostgreSQL)
    def criar_tabelas_relacionais_neon(self):
        """Cria a estrutura modelada do banco relacional no Neon através da engine_neon."""
        if not self.engine_neon:
            raise ValueError("NEON_URL não está configurada no arquivo .env.")

        queries = [
            """CREATE TABLE IF NOT EXISTS local (
                id_local     INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
                distrito     VARCHAR NOT NULL,
                bairro       VARCHAR NOT NULL,
                bairro_area  VARCHAR,
                UNIQUE (distrito, bairro, bairro_area)
            )""",
            """CREATE TABLE IF NOT EXISTS agente (
                id_agente  INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
                nome       VARCHAR NOT NULL,
                matricula  VARCHAR UNIQUE
            )""",
            """CREATE TABLE IF NOT EXISTS ovitrampas (
                id_ovitrampa  INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
                id_local      INTEGER NOT NULL REFERENCES local(id_local),
                nome          VARCHAR NOT NULL,
                endereco      VARCHAR,
                latitude      DOUBLE PRECISION,
                longitude     DOUBLE PRECISION
            )""",
            """CREATE TABLE IF NOT EXISTS edl (
                id_edl      INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
                id_local    INTEGER NOT NULL REFERENCES local(id_local),
                nome        VARCHAR NOT NULL,
                endereco    VARCHAR,
                referencia  VARCHAR,
                latitude    DOUBLE PRECISION,
                longitude   DOUBLE PRECISION
            )""",
        ]

        for ano in self.anos:
            queries.append(f"""CREATE TABLE IF NOT EXISTS ciclos_{ano} (
                id_ciclo       INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
                id_ovitrampa   INTEGER NOT NULL REFERENCES ovitrampas(id_ovitrampa),
                id_agente      INTEGER NOT NULL REFERENCES agente(id_agente),
                ciclo          INTEGER NOT NULL CHECK (ciclo BETWEEN 1 AND 24),
                contagem       INTEGER,
                obs            VARCHAR,
                data_visita    TIMESTAMP,
                data_contagem  TIMESTAMP,
                UNIQUE (id_ovitrampa, ciclo)
            )""")

        with self.engine_neon.begin() as conn:
            for comando in queries:
                conn.execute(text(comando))
        print("[Neon] Estrutura de tabelas relacionais criada/verificada com sucesso!")

    def load_neon(self, df: pd.DataFrame, nome_tabela: str):
        """Envia um DataFrame para a respectiva tabela no Neon usando engine_neon."""
        if not self.engine_neon:
            raise ValueError("NEON_URL não está configurada no arquivo .env.")

        df_envio = df.copy()
        # Converte colunas de data em formato texto para datetime nas tabelas de ciclos
        for col_dt in ("data_visita", "data_contagem"):
            if col_dt in df_envio.columns:
                df_envio[col_dt] = pd.to_datetime(df_envio[col_dt], errors="coerce")

        # Mantém contagem como inteiro anulável (Int64) para não enviar float ao Postgres
        if "contagem" in df_envio.columns:
            df_envio["contagem"] = pd.to_numeric(df_envio["contagem"], errors="coerce").astype("Int64")

        with self.engine_neon.begin() as conn:
            df_envio.to_sql(
                name=nome_tabela,
                con=conn,
                if_exists="append",
                index=False,
                method="multi",
                chunksize=2000,
            )
        print(f"[Neon] Dados salvos com sucesso na tabela '{nome_tabela}' ({len(df_envio)} registros)!")

    def migrar_sqlite_para_neon(self, limpar_antes: bool = True):
        """
        Cria as tabelas relacionais no Neon e transfere todos os dados do SQLite
        diretamente para o Neon através da engine_neon.
        """
        self.criar_tabelas_relacionais_neon()

        if limpar_antes:
            with self.engine_neon.begin() as conn:
                tabelas_str = ", ".join(self.tabelas)
                conn.execute(text(f"TRUNCATE TABLE {tabelas_str} RESTART IDENTITY CASCADE;"))
            print("[Neon] Tabelas limpas para evitar duplicidade de chaves primárias.")

        for tabela in self.tabelas:
            df_sqlite = self.ler_tabela_sqlite(tabela)
            if not df_sqlite.empty:
                self.load_neon(df_sqlite, tabela)
            else:
                print(f"[Neon] Tabela '{tabela}' está vazia no SQLite, pulando envio.")

    # ----------------------------------------------------------------- JSON Local
    def load_json(self, nome_doc: str, data: list[dict]) -> Path:
        """Salva uma lista de dicionários em um arquivo .json dentro da pasta JSON/."""
        caminho_arquivo = self.json_dir / f"{nome_doc}.json"
        with open(caminho_arquivo, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=2, ensure_ascii=False)
        print(f"[JSON] Arquivo '{caminho_arquivo.name}' salvo em '{self.json_dir}' ({len(data)} registros).")
        return caminho_arquivo

    def exportar_sqlite_para_json(self) -> dict[str, Path]:
        """
        Lê todas as tabelas do SQLite, converte NaN/NaT para None e salva cada tabela
        em seu respectivo arquivo dentro da pasta JSON/.
        """
        arquivos_gerados = {}
        for tabela in self.tabelas:
            df = self.ler_tabela_sqlite(tabela)
            # Garante que tipos inteiros anuláveis não virem float (ex: 370.0 -> 370)
            if "contagem" in df.columns:
                df["contagem"] = pd.to_numeric(df["contagem"], errors="coerce").astype("Int64")

            # Converte NaN/NaT do pandas para None nativo do Python para gerar JSON válido
            df_limpo = df.replace({np.nan: None, pd.NA: None})
            registros = df_limpo.to_dict(orient="records")
            caminho = self.load_json(tabela, registros)
            arquivos_gerados[tabela] = caminho

        return arquivos_gerados

    # ----------------------------------------------------------------- MongoDB
    def load_mongo(
        self,
        data: list[dict],
        db_name: str,
        collection_name: str,
        limpar_antes: bool = True,
        batch_size: int = 5000,
    ) -> None:
        """Insere os documentos na coleção correspondente do MongoDB em lotes."""
        if not self.client:
            raise ValueError("MONGO_URL não está configurada no arquivo .env.")

        try:
            collection = self.client[db_name][collection_name]
            if limpar_antes:
                collection.delete_many({})

            if data:
                for i in range(0, len(data), batch_size):
                    lote = data[i : i + batch_size]
                    collection.insert_many(lote, ordered=False)

            print(
                f"[MongoDB] {len(data)} documentos inseridos com sucesso na coleção '{collection_name}'!"
            )
        except OperationFailure as e:
            if e.code == 8000:
                raise RuntimeError(
                    "Falha de autenticação no MongoDB Atlas (code 8000 - bad auth). "
                    "Verifique no arquivo .env se o usuário e a senha em MONGO_URL estão corretos "
                    "(e se o usuário existe em 'Database Access' no painel do Atlas com permissão de leitura/escrita)."
                ) from e
            raise

    def carregar_jsons_para_mongo(self, db_name: str = "gevacz"):
        """Lê os arquivos da pasta JSON/ e envia cada um para sua coleção no MongoDB."""
        for tabela in self.tabelas:
            caminho_json = self.json_dir / f"{tabela}.json"
            if not caminho_json.exists():
                print(f"[MongoDB] Arquivo '{caminho_json}' não encontrado, pulando...")
                continue

            with open(caminho_json, "r", encoding="utf-8") as file:
                dados_json = json.load(file)

            self.load_mongo(data=dados_json, db_name=db_name, collection_name=tabela)

    # ----------------------------------------------------------------- Fechamento de Conexões
    def fechar_conexoes(self):
        """Fecha todas as conexões e pools abertos (Neon, SQLite e MongoDB)."""
        if self.engine_neon is not None:
            self.engine_neon.dispose()
            print("[Conexões] Pool da engine_neon encerrado.")

        if self.engine_sqlite is not None:
            self.engine_sqlite.dispose()
            print("[Conexões] Pool da engine_sqlite encerrado.")

        if self.client is not None:
            self.client.close()
            print("[Conexões] Conexão com o MongoDB encerrada.")