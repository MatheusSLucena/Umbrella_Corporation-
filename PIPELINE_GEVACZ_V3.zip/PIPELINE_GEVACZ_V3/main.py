import zipfile
from pathlib import Path
from src.extract import Extract
from src.transform import Transform
from src.load import Load


def popular_sqlite_se_necessario(base_dir: Path, carregador: Load):
    """Executa a extração e transformação para o SQLite caso ainda não esteja populado."""
    zip_path = base_dir / "Dados_gevacz.zip"
    pasta_dados = base_dir / "Dados_gevacz"

    if not pasta_dados.exists() and zip_path.exists():
        print("Extraindo arquivo Dados_gevacz.zip...")
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(base_dir)

    extrator = Extract(base_dir=str(base_dir))
    transformador = Transform(csv_edls_path=str(base_dir / "dados_EDLs.csv"))

    print("1/4 - Extraindo dados brutos das planilhas e CSV...")
    df_edls_raw = transformador.carregar_dados_edls()
    df_ovt_raw = extrator.extract_ovitrampas_geo()
    df_agentes_edl = extrator.extract_agentes_edls()
    dados_monitoramento = extrator.extract_monitoramento_ovitrampas()

    print("2/4 - Transformando Locais, Ovitrampas, EDLs e Agentes...")
    df_ovt_prep = transformador.preparar_ovitrampas_brutas(df_ovt_raw)
    df_local, lookup_local = transformador.construir_tabela_local(df_ovt_prep, df_edls_raw)
    df_ovitrampas = transformador.estruturar_ovitrampas(df_ovt_prep, lookup_local)
    df_edl = transformador.estruturar_edls(df_edls_raw, df_local, lookup_local)
    df_agente, lookup_agente = transformador.construir_tabela_agentes(
        df_ovt_prep=df_ovt_prep,
        df_agentes_edl=df_agentes_edl,
        dados_monitoramento=dados_monitoramento,
    )

    print("3/4 - Transformando ciclos de monitoramento (2024, 2025 e 2026)...")
    tabelas_ciclos = transformador.extrair_ciclos_das_planilhas(
        dados_monitoramento=dados_monitoramento,
        df_ovitrampas=df_ovitrampas,
        df_ovt_prep=df_ovt_prep,
        lookup_agente=lookup_agente,
    )

    print("4/4 - Salvando dados estruturados no SQLite (gevacz.db)...")
    carregador.criar_tabelas_relacionais_sqlite()
    carregador.load_sqlite(df_local, "local")
    carregador.load_sqlite(df_agente, "agente")
    carregador.load_sqlite(df_ovitrampas, "ovitrampas")
    carregador.load_sqlite(df_edl, "edl")

    for ano, df_ciclo in tabelas_ciclos.items():
        carregador.load_sqlite(df_ciclo, f"ciclos_{ano}")


def executar_pipeline():
    base_dir = Path(__file__).parent.resolve()
    caminho_sqlite = base_dir / "gevacz.db"
    pasta_json = base_dir / "JSON"

    carregador = Load(
        db_path=str(caminho_sqlite),
        json_dir=str(pasta_json),
    )

    try:
        # Se o arquivo gevacz.db ainda não existir ou estiver vazio, roda o ETL para o SQLite
        if not caminho_sqlite.exists() or caminho_sqlite.stat().st_size == 0:
            popular_sqlite_se_necessario(base_dir, carregador)
        else:
            print(f"[SQLite] Banco '{caminho_sqlite.name}' já encontrado. Iniciando migração...")

        # 1. Cria tabelas relacionais no Neon e passa os dados do SQLite direto para o Neon
        print("\n--- Etapa 1: Migração SQLite -> Neon (PostgreSQL) ---")
        carregador.migrar_sqlite_para_neon(limpar_antes=True)

        # 2. Exporta todas as tabelas do SQLite para arquivos JSON na pasta JSON/
        print("\n--- Etapa 2: Exportação das Tabelas para a pasta JSON/ ---")
        carregador.exportar_sqlite_para_json()

        # 3. Envia os arquivos da pasta JSON/ para o MongoDB
        print("\n--- Etapa 3: Carga dos arquivos JSON -> MongoDB ---")
        carregador.carregar_jsons_para_mongo(db_name="gevacz")

        print("\nPipeline completo finalizado com sucesso!")

    finally:
        # 4. Fecha todas as conexões abertas (Neon, SQLite e MongoDB)
        print("\n--- Encerrando Conexões ---")
        carregador.fechar_conexoes()


if __name__ == "__main__":
    executar_pipeline()